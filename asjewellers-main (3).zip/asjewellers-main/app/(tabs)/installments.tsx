import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Alert,
  TextInput,
  Modal,
} from "react-native";
import { supabase } from "@/lib/supabase";
import { useLocalSearchParams } from "expo-router";

export default function InstallmentsScreen() {
  const { subscription_id } = useLocalSearchParams();

  const [installments, setInstallments] = useState<any[]>([]);
  const [totalPaid, setTotalPaid] = useState(0);
  const [remaining, setRemaining] = useState(18000); // 12 × 1500

  const [loading, setLoading] = useState(true);

  // Modal States
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any>(null);

  const [editRate, setEditRate] = useState("");
  const [editReceipt, setEditReceipt] = useState("");
  const [editMode, setEditMode] = useState("Cash");

  // Fetch Installments
  const fetchInstallments = async () => {
    setLoading(true);

    const { data, error } = await supabase
      .from("installments")
      .select("*")
      .eq("subscription_id", subscription_id)
      .order("installment_no", { ascending: true });

    if (error) {
      console.log(error);
      Alert.alert("Error", "Failed to load installments");
      setLoading(false);
      return;
    }

    setInstallments(data);

    const paid = data.reduce((sum, item) => sum + Number(item.amount), 0);
    setTotalPaid(paid);
    setRemaining(18000 - paid);

    setLoading(false);
  };

  useEffect(() => {
    fetchInstallments();
  }, []);

  // ------------------- DELETE INSTALLMENT -------------------
  const deleteInstallment = async (id: string) => {
    Alert.alert("Confirm", "Are you sure you want to delete this installment?", [
      { text: "Cancel" },
      {
        text: "Delete",
        onPress: async () => {
          const { error } = await supabase
            .from("installments")
            .delete()
            .eq("id", id);

          if (error) {
            Alert.alert("Error", error.message);
            return;
          }

          Alert.alert("Success", "Installment deleted");
          fetchInstallments();
        },
      },
    ]);
  };

  // ------------------- OPEN EDIT MODAL -------------------
  const openEditModal = (item: any) => {
    setSelectedItem(item);
    setEditReceipt(item.receipt_no);
    setEditRate(item.gold_rate);
    setEditMode(item.payment_mode);
    setEditModalVisible(true);
  };

  // ------------------- SAVE EDIT -------------------
  const saveEdit = async () => {
    const weight = (1500 / parseFloat(editRate)).toFixed(3);

    const { error } = await supabase
      .from("installments")
      .update({
        gold_rate: editRate,
        receipt_no: editReceipt,
        payment_mode: editMode,
        weight,
      })
      .eq("id", selectedItem.id);

    if (error) {
      Alert.alert("Error", error.message);
      return;
    }

    Alert.alert("Success", "Installment updated");
    setEditModalVisible(false);
    fetchInstallments();
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.heading}>Your Installments</Text>

      {/* Summary */}
      <View style={styles.summaryCard}>
        <Text style={styles.summaryText}>Total Paid: ₹ {totalPaid}</Text>
        <Text style={styles.summaryText}>Remaining: ₹ {remaining}</Text>
      </View>

      {installments.map((item) => (
        <View key={item.id} style={styles.card}>
          <Text style={styles.title}>Installment #{item.installment_no}</Text>

          <View style={styles.row}>
            <Text style={styles.label}>Receipt No:</Text>
            <Text style={styles.value}>{item.receipt_no}</Text>
          </View>

          <View style={styles.row}>
            <Text style={styles.label}>Gold Rate:</Text>
            <Text style={styles.value}>{item.gold_rate}</Text>
          </View>

          <View style={styles.row}>
            <Text style={styles.label}>Payment Mode:</Text>
            <Text style={styles.value}>{item.payment_mode}</Text>
          </View>

          <View style={styles.row}>
            <Text style={styles.label}>Weight:</Text>
            <Text style={styles.value}>{item.weight} g</Text>
          </View>

          {/* Buttons */}
          <View style={styles.btnRow}>
            <TouchableOpacity
              style={styles.editBtn}
              onPress={() => openEditModal(item)}
            >
              <Text style={styles.btnText}>EDIT</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.deleteBtn}
              onPress={() => deleteInstallment(item.id)}
            >
              <Text style={styles.btnText}>DELETE</Text>
            </TouchableOpacity>
          </View>
        </View>
      ))}

      {/* ------------ EDIT MODAL ------------ */}
      <Modal visible={editModalVisible} transparent>
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Edit Installment</Text>

            <TextInput
              value={editReceipt}
              onChangeText={setEditReceipt}
              placeholder="Receipt No"
              style={styles.modalInput}
            />

            <TextInput
              value={editRate}
              onChangeText={setEditRate}
              placeholder="Gold Rate"
              keyboardType="numeric"
              style={styles.modalInput}
            />

            <View style={{ flexDirection: "row", flexWrap: "wrap" }}>
              {["Cash", "Card", "UPI", "Bank"].map((mode) => (
                <TouchableOpacity
                  key={mode}
                  style={[
                    styles.modeBtn,
                    editMode === mode && styles.activeMode,
                  ]}
                  onPress={() => setEditMode(mode)}
                >
                  <Text
                    style={[
                      styles.modeText,
                      editMode === mode && styles.activeModeText,
                    ]}
                  >
                    {mode}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <View style={styles.modalBtnRow}>
              <TouchableOpacity
                style={styles.saveBtn}
                onPress={saveEdit}
              >
                <Text style={styles.saveText}>Save</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.cancelBtn}
                onPress={() => setEditModalVisible(false)}
              >
                <Text style={styles.saveText}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: "#111", padding: 15 },
  heading: {
    color: "#FFD700",
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 15,
  },
  summaryCard: {
    backgroundColor: "#222",
    borderRadius: 10,
    padding: 15,
    borderColor: "#FFD700",
    borderWidth: 1,
    marginBottom: 15,
  },
  summaryText: {
    color: "#FFD700",
    fontSize: 16,
    fontWeight: "bold",
  },
  card: {
    backgroundColor: "#222",
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    borderColor: "#FFD700",
    borderWidth: 1,
  },
  title: { color: "#FFD700", fontSize: 18, fontWeight: "bold" },
  row: { flexDirection: "row", justifyContent: "space-between", marginTop: 5 },
  label: { color: "#bbb" },
  value: { color: "#fff", fontWeight: "bold" },
  btnRow: { flexDirection: "row", marginTop: 10, gap: 10 },
  editBtn: {
    flex: 1,
    backgroundColor: "#4CAF50",
    padding: 10,
    borderRadius: 8,
  },
  deleteBtn: {
    flex: 1,
    backgroundColor: "#E53935",
    padding: 10,
    borderRadius: 8,
  },
  btnText: { color: "#fff", textAlign: "center", fontWeight: "bold" },

  // Modal
  modalBg: {
    backgroundColor: "rgba(0,0,0,0.7)",
    flex: 1,
    justifyContent: "center",
    padding: 20,
  },
  modalCard: {
    backgroundColor: "#222",
    padding: 20,
    borderRadius: 10,
    borderColor: "#FFD700",
    borderWidth: 1,
  },
  modalTitle: { color: "#FFD700", fontSize: 18, fontWeight: "bold" },
  modalInput: {
    backgroundColor: "#333",
    borderRadius: 6,
    borderWidth: 1,
    borderColor: "#FFD700",
    padding: 10,
    marginTop: 10,
    color: "#fff",
  },
  modeBtn: {
    padding: 8,
    borderWidth: 1,
    borderColor: "#FFD700",
    borderRadius: 8,
    marginRight: 10,
    marginTop: 10,
  },
  activeMode: { backgroundColor: "#FFD700" },
  modeText: { color: "#FFD700" },
  activeModeText: { color: "#000", fontWeight: "bold" },

  modalBtnRow: { flexDirection: "row", marginTop: 20, gap: 10 },
  saveBtn: {
    flex: 1,
    backgroundColor: "#4CAF50",
    padding: 12,
    borderRadius: 8,
  },
  cancelBtn: {
    flex: 1,
    backgroundColor: "#E53935",
    padding: 12,
    borderRadius: 8,
  },
  saveText: { color: "#fff", textAlign: "center", fontWeight: "bold" },
});
