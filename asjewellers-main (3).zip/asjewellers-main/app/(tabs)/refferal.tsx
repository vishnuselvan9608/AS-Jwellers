import { useState, useEffect } from "react";
import { View, Text, StyleSheet, TouchableOpacity, Share, ScrollView } from "react-native";
import { Copy, Link as LinkIcon } from "lucide-react-native";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/lib/supabase";

export default function ReferralScreen() {
  const { profile } = useAuth();

  const referralCode = profile?.referral_code || "N/A";
  const inviteLink = `https://asjewellers.in/signup?ref=${referralCode}`;

  // 👉 Real referral data
  const totalReferrals = 17;               // person did 17 referrals
  const bonusPerReferral = 150;            // each referral gives ₹150
  const referralEarnings = totalReferrals * bonusPerReferral; // AUTO CALCULATED

  // 👉 Bonus level table (from image)
  const bonusLevels = [
    { level: 1, amount: 150, percent: "10%" },
    { level: 2, amount: 45, percent: "3%" },
    { level: 3, amount: 30, percent: "2%" },
    { level: 4, amount: 22.5, percent: "1.5%" },
    { level: 5, amount: 11.25, percent: "0.75%" },
    { level: 6, amount: 11.25, percent: "0.75%" },
    { level: 7, amount: 7.5, percent: "0.5%" },
    { level: 8, amount: 7.5, percent: "0.5%" },
    { level: 9, amount: 7.5, percent: "0.5%" },
    { level: 10, amount: 7.5, percent: "0.5%" },
  ];

  const totalBonus = 300;

  const shareReferralLink = async () => {
    try {
      await Share.share({
        message: `Join A.S Jewellers Gold Saving Plan.\nUse my referral code: ${referralCode}\nSignup here: ${inviteLink}`,
      });
    } catch (error) {
      console.log("Share Error:", error);
    }
  };

  const copyText = async (text: string) => {
    await Share.share({ message: text });
  };

  return (
    <ScrollView style={styles.container}>

      <Text style={styles.title}>Referral Program</Text>

      {/* REFERRAL CODE */}
      <View style={styles.card}>
        <Text style={styles.cardLabel}>Your Referral Code</Text>
        <Text style={styles.bigText}>{referralCode}</Text>

        <TouchableOpacity style={styles.actionBtn} onPress={() => copyText(referralCode)}>
          <Copy size={18} color="#000" />
          <Text style={styles.actionText}>Copy Code</Text>
        </TouchableOpacity>
      </View>

      {/* INVITE LINK */}
      <View style={styles.card}>
        <Text style={styles.cardLabel}>Invite Link</Text>
        <Text style={styles.smallText}>{inviteLink}</Text>

        <TouchableOpacity style={styles.actionBtn} onPress={() => copyText(inviteLink)}>
          <LinkIcon size={18} color="#000" />
          <Text style={styles.actionText}>Copy Link</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.actionBtn, { backgroundColor: "#FFD700", marginTop: 10 }]}
          onPress={shareReferralLink}
        >
          <Text style={styles.actionText}>Share Invite</Text>
        </TouchableOpacity>
      </View>

      {/* REFERRAL EARNINGS */}
      <View style={styles.card}>
        <Text style={styles.cardLabel}>Your Referral Earnings</Text>

        <View style={styles.statsRow}>
          <Text style={styles.statsLabel}>Total Referrals:</Text>
          <Text style={styles.statsValue}>{totalReferrals}</Text>
        </View>

        <View style={styles.statsRow}>
          <Text style={styles.statsLabel}>Bonus Per Referral:</Text>
          <Text style={styles.statsValue}>₹ {bonusPerReferral}</Text>
        </View>

        <View style={styles.statsRowTotal}>
          <Text style={styles.statsTotalLabel}>Total Earnings:</Text>
          <Text style={styles.statsTotalValue}>₹ {referralEarnings}</Text>
        </View>
      </View>

      {/* BONUS TABLE */}
      <View style={styles.card}>
        <Text style={styles.cardLabel}>Referral Bonus Structure</Text>

        <View style={styles.tableHeader}>
          <Text style={styles.tableHeadText}>Level</Text>
          <Text style={styles.tableHeadText}>Bonus</Text>
          <Text style={styles.tableHeadText}>%</Text>
        </View>

        {bonusLevels.map((row) => (
          <View key={row.level} style={styles.tableRow}>
            <Text style={styles.tableText}>L{row.level}</Text>
            <Text style={styles.tableText}>₹ {row.amount}</Text>
            <Text style={styles.tableText}>{row.percent}</Text>
          </View>
        ))}

        <View style={styles.totalRow}>
          <Text style={styles.totalLabel}>TOTAL BONUS</Text>
          <Text style={styles.totalValue}>₹ {totalBonus}</Text>
        </View>
      </View>

      {/* 🔥 NEW TOTAL REFERRAL SUMMARY BLOCK ADDED */}
      <View style={styles.card}>
        <Text style={styles.cardLabel}>Overall Referral Summary</Text>

        <View style={styles.statsRow}>
          <Text style={styles.statsLabel}>Total Referrals:</Text>
          <Text style={styles.statsValue}>{totalReferrals}</Text>
        </View>

        <View style={styles.statsRow}>
          <Text style={styles.statsLabel}>Bonus Per Referral:</Text>
          <Text style={styles.statsValue}>₹ {bonusPerReferral}</Text>
        </View>

        <View style={styles.statsRowTotal}>
          <Text style={styles.statsTotalLabel}>Total Earnings:</Text>
          <Text style={styles.statsTotalValue}>₹ {referralEarnings}</Text>
        </View>
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0F172A",
    padding: 20,
  },

  title: {
    fontSize: 26,
    color: "#FFD700",
    fontWeight: "bold",
    marginBottom: 20,
  },

  card: {
    backgroundColor: "#1E293B",
    padding: 20,
    borderRadius: 16,
    marginBottom: 20,
  },

  cardLabel: {
    color: "#94A3B8",
    fontSize: 14,
    marginBottom: 8,
  },

  bigText: {
    color: "#FFD700",
    fontSize: 32,
    fontWeight: "bold",
    letterSpacing: 2,
    textAlign: "center",
    marginVertical: 10,
  },

  smallText: {
    color: "#FFF",
    fontSize: 14,
    marginBottom: 15,
  },

  actionBtn: {
    backgroundColor: "#FFF",
    padding: 10,
    borderRadius: 10,
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    justifyContent: "center",
  },

  actionText: {
    fontSize: 14,
    fontWeight: "600",
    color: "#000",
  },

  statsRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 6,
    borderBottomColor: "#334155",
    borderBottomWidth: 1,
  },

  statsRowTotal: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingTop: 10,
    marginTop: 10,
    borderTopColor: "#FFD700",
    borderTopWidth: 2,
  },

  statsLabel: {
    color: "#FFF",
    fontSize: 15,
  },

  statsValue: {
    color: "#FFD700",
    fontSize: 16,
    fontWeight: "bold",
  },

  statsTotalLabel: {
    color: "#FFD700",
    fontSize: 18,
    fontWeight: "bold",
  },

  statsTotalValue: {
    color: "#0BF172",
    fontSize: 20,
    fontWeight: "bold",
  },

  tableHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "#334155",
    paddingBottom: 8,
    marginBottom: 5,
  },

  tableHeadText: {
    color: "#FFD700",
    fontSize: 14,
    fontWeight: "bold",
  },

  tableRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: "#334155",
  },

  tableText: {
    color: "#FFF",
    fontSize: 14,
  },

  totalRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 14,
    paddingTop: 10,
    borderTopWidth: 2,
    borderTopColor: "#FFD700",
  },

  totalLabel: {
    color: "#FFD700",
    fontSize: 18,
    fontWeight: "bold",
  },

  totalValue: {
    color: "#0BF172",
    fontSize: 20,
    fontWeight: "bold",
  },
});
