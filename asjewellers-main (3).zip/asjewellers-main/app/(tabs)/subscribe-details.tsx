import { View, Text, StyleSheet, TouchableOpacity, Alert } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { supabase } from "@/lib/supabase";
import { useState } from "react";

export default function SubscribeDetails() {
  const router = useRouter();
  const { plan_id, plan_name, amount, user_id } = useLocalSearchParams();
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async () => {
    setLoading(true);

    const startDate = new Date().toISOString().slice(0, 10);

    // 1️⃣ Insert subscription record
    const { data, error } = await supabase
      .from("user_subscriptions")
      .insert({
        user_id,
        plan_id,
        start_date: startDate,
        status: "active",
      })
      .select()
      .single();

    if (error) {
      Alert.alert("Error", error.message);
      setLoading(false);
      return;
    }

    setLoading(false);

    // 2️⃣ Navigate to PAYMENT PAGE
    router.push({
      pathname: "/(tabs)/payment",
      params: {
        subscription_id: data.id,
        plan_id,
        amount,
        date: startDate,
        user_id,
      },
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Confirm Subscription</Text>

      <View style={styles.card}>
        <Text style={styles.label}>Plan ID</Text>
        <Text style={styles.value}>{plan_id}</Text>

        <Text style={styles.label}>Plan Name</Text>
        <Text style={styles.value}>{plan_name}</Text>

        <Text style={styles.label}>Amount</Text>
        <Text style={styles.value}>₹ {amount}</Text>
      </View>

      <TouchableOpacity style={styles.button} onPress={handleSubscribe}>
        <Text style={styles.buttonText}>
          {loading ? "Processing..." : "Confirm & Subscribe"}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#111", padding: 20 },
  heading: {
    color: "#FFD700",
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
  },
  card: {
    marginTop: 20,
    padding: 20,
    backgroundColor: "#222",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#FFD700",
  },
  label: { color: "#bbb", marginTop: 10 },
  value: { color: "white", fontSize: 16, fontWeight: "bold" },
  button: {
    backgroundColor: "#FFD700",
    padding: 15,
    marginTop: 40,
    borderRadius: 10,
  },
  buttonText: { textAlign: "center", fontWeight: "bold", fontSize: 18 },
});
