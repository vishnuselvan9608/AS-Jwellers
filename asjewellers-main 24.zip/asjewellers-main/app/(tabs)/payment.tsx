import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { supabase } from "@/lib/supabase";

export default function PaymentScreen() {
  const router = useRouter();
  const { subscription_id, plan_id, amount, date, user_id } =
    useLocalSearchParams();

  const [loading, setLoading] = useState(false);

  const [goldRate, setGoldRate] = useState("");
  const [receiptNo, setReceiptNo] = useState("");
  const [paymentMode, setPaymentMode] = useState("Cash");
  const [nextInstallmentNo, setNextInstallmentNo] = useState(1);

  // ➤ Auto-calc next installment number
  const fetchNextInstallmentNo = async () => {
    const { data, error } = await supabase
      .from("installments")
      .select("installment_no")
      .eq("subscription_id", subscription_id)
      .order("installment_no", { ascending: false })
      .limit(1);

    if (error) {
      console.log(error);
      return;
    }

    setNextInstallmentNo((data?.[0]?.installment_no || 0) + 1);
  };

  useEffect(() => {
    fetchNextInstallmentNo();
  }, []);

  // ➤ Auto calculate gold weight based on 1500 fixed amount
  const calculateWeight = () => {
    const rate = parseFloat(goldRate);
    if (!rate || rate <= 0) return "0.000";
    return (1500 / rate).toFixed(3);
  };

  const handlePayment = async () => {
    if (!goldRate || !receiptNo) {
      Alert.alert("Missing", "Please enter Gold Rate & Receipt No");
      return;
    }

    setLoading(true);

    const weight = calculateWeight();
    const today = new Date().toISOString().slice(0, 10);

    const { error } = await supabase.from("installments").insert([
      {
        subscription_id,
        installment_no: nextInstallmentNo,
        amount: 1500,
        gold_rate: goldRate,
        weight,
        payment_date: today,
        payment_mode: paymentMode,
        receipt_no: receiptNo,
      },
    ]);

    if (error) {
      console.log(error);
      Alert.alert("Error", error.message);
      setLoading(false);
      return;
    }

    Alert.alert("Success", "Payment Added!");

    setLoading(false);

    // Navigate to Installment Summary Page
    router.push({
      pathname: "/(tabs)/installments",
      params: { subscription_id, amount },
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Make Payment</Text>

      <View style={styles.card}>
        <Text style={styles.label}>Plan ID</Text>
        <Text style={styles.value}>{plan_id}</Text>

        <Text style={styles.label}>Installment Amount</Text>
        <Text style={styles.value}>₹ 1500</Text>

        <Text style={styles.label}>Next Installment No</Text>
        <Text style={styles.value}>{nextInstallmentNo}</Text>
      </View>

      <TextInput
        placeholder="Enter Gold Rate"
        keyboardType="numeric"
        value={goldRate}
        onChangeText={setGoldRate}
        style={styles.input}
      />

      <TextInput
        placeholder="Enter Receipt No"
        value={receiptNo}
        onChangeText={setReceiptNo}
        style={styles.input}
      />

      <Text style={styles.label}>Payment Mode</Text>

      <View style={styles.modeRow}>
        {["Cash", "Card", "UPI", "Bank"].map((mode) => (
          <TouchableOpacity
            key={mode}
            style={[
              styles.modeBtn,
              paymentMode === mode && styles.activeMode,
            ]}
            onPress={() => setPaymentMode(mode)}
          >
            <Text
              style={[
                styles.modeText,
                paymentMode === mode && styles.activeModeText,
              ]}
            >
              {mode}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity style={styles.payBtn} onPress={handlePayment}>
        <Text style={styles.payText}>
          {loading ? "Processing..." : "Submit Payment"}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#111", padding: 20 },
  heading: {
    color: "#FFD700",
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
  },
  card: {
    backgroundColor: "#222",
    padding: 20,
    marginVertical: 20,
    borderRadius: 10,
    borderColor: "#FFD700",
    borderWidth: 1,
  },
  label: { color: "#bbb", fontSize: 14, marginTop: 10 },
  value: { color: "#fff", fontSize: 18, fontWeight: "bold" },
  input: {
    backgroundColor: "#222",
    color: "#fff",
    padding: 12,
    marginVertical: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#FFD700",
  },
  modeRow: { flexDirection: "row", marginVertical: 10, flexWrap: "wrap" },
  modeBtn: {
    borderWidth: 1,
    borderColor: "#FFD700",
    padding: 10,
    borderRadius: 8,
    marginRight: 10,
    marginTop: 5,
  },
  activeMode: { backgroundColor: "#FFD700" },
  modeText: { color: "#FFD700" },
  activeModeText: { color: "#000", fontWeight: "bold" },
  payBtn: {
    backgroundColor: "#FFD700",
    padding: 15,
    marginTop: 20,
    borderRadius: 10,
  },
  payText: { textAlign: "center", fontSize: 18, fontWeight: "bold" },
});
