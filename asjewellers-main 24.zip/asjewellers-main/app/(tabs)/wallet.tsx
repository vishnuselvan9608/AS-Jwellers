import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from "react-native";
import { router } from "expo-router";
import { useState } from "react";

export default function Wallet() {
  const [wallet, setWallet] = useState({
    savings: 1200,
    bonus: 350,
    totalEarnings: 3500,
    totalWithdrawn: 1200,
    autoWithdrawEnabled: true,
    autoWithdrawThreshold: 500,
    paymentMethod: "UPI - vishnu@upi",
    accountDetails: {
      name: "Vishnu Tamilselvan",
      bank: "SBI Bank",
      accountNo: "XXXXXX4521",
      ifsc: "SBIN0001789",
    },
    transactions: [
      { id: 1, type: "Added", amount: 500, date: "2025-01-12" },
      { id: 2, type: "Bonus", amount: 100, date: "2025-01-10" },
    ],
  });

  const total = wallet.savings + wallet.bonus;

  return (
    <ScrollView style={styles.container}>

      {/* TOP HEADING */}
      <Text style={styles.heading}>My Wallet</Text>

      {/* WALLET BALANCE */}
      <View style={styles.card}>
        <Text style={styles.label}>Savings Wallet</Text>
        <Text style={styles.value}>₹ {wallet.savings}</Text>

        <Text style={styles.label}>Referral Bonus</Text>
        <Text style={styles.value}>₹ {wallet.bonus}</Text>

        <Text style={styles.label}>Total Balance</Text>
        <Text style={[styles.value, { color: "#FFD700" }]}>₹ {total}</Text>
      </View>

      {/* EXTRA DETAILS SECTION */}
      <Text style={styles.subHeading}>Wallet Details</Text>

      <View style={styles.infoCard}>
        <Text style={styles.infoText}>Total Earnings: ₹ {wallet.totalEarnings}</Text>
        <Text style={styles.infoText}>Total Withdrawn: ₹ {wallet.totalWithdrawn}</Text>
        <Text style={styles.infoText}>
          Auto Withdraw Enabled: {wallet.autoWithdrawEnabled ? "Yes" : "No"}
        </Text>
        <Text style={styles.infoText}>
          Auto Withdraw Threshold: ₹ {wallet.autoWithdrawThreshold}
        </Text>
        <Text style={styles.infoText}>Payment Method: {wallet.paymentMethod}</Text>
      </View>

      {/* ACCOUNT DETAILS */}
      <Text style={styles.subHeading}>Account Details</Text>
      <View style={styles.card}>
        <Text style={styles.label}>Name</Text>
        <Text style={styles.value}>{wallet.accountDetails.name}</Text>

        <Text style={styles.label}>Bank</Text>
        <Text style={styles.value}>{wallet.accountDetails.bank}</Text>

        <Text style={styles.label}>Account Number</Text>
        <Text style={styles.value}>{wallet.accountDetails.accountNo}</Text>

        <Text style={styles.label}>IFSC Code</Text>
        <Text style={styles.value}>{wallet.accountDetails.ifsc}</Text>
      </View>

      {/* SUBSCRIPTION */}
      <TouchableOpacity
        style={styles.button}
        onPress={() =>
          router.push({
            pathname: "/(tabs)/subscribe-details",
            params: { balance: total },
          })
        }
      >
        <Text style={styles.buttonText}>Subscription</Text>
      </TouchableOpacity>

      {/* TRANSACTION HISTORY */}
      <TouchableOpacity
        style={[styles.button, { backgroundColor: "#444", marginTop: 15 }]}
        onPress={() =>
          router.push({
            pathname: "/transactions",
            params: { items: JSON.stringify(wallet.transactions) },
          })
        }
      >
        <Text style={styles.buttonText}>Transaction History</Text>
      </TouchableOpacity>

      {/* SIMULATE PAYMENT */}
      <TouchableOpacity
        style={[styles.button, { backgroundColor: "#00C853", marginTop: 15 }]}
        onPress={() =>
          router.push({
            pathname: "/payment",
            params: { amount: "300", bonus: "50" },
          })
        }
      >
        <Text style={styles.buttonText}>Simulate Payment</Text>
      </TouchableOpacity>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#111", padding: 20 },

  heading: {
    color: "#FFD700",
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    marginVertical: 15,
  },

  card: {
    marginTop: 10,
    backgroundColor: "#222",
    padding: 20,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: "#FFD700",
    marginBottom: 15,
  },

  label: { color: "#aaa", marginTop: 12, fontSize: 14 },
  value: { color: "#fff", fontSize: 20, fontWeight: "bold" },

  subHeading: {
    color: "#FFD700",
    fontSize: 20,
    fontWeight: "bold",
    marginTop: 25,
  },

  infoCard: {
    backgroundColor: "#222",
    padding: 20,
    marginTop: 10,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#555",
  },

  infoText: {
    color: "#fff",
    fontSize: 15,
    marginVertical: 4,
  },

  button: {
    marginTop: 25,
    backgroundColor: "#FFD700",
    padding: 15,
    borderRadius: 12,
  },

  buttonText: {
    textAlign: "center",
    color: "#111",
    fontSize: 18,
    fontWeight: "bold",
  },
});
