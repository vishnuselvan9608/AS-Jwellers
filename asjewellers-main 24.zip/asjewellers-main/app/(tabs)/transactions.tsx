import React from "react";
import { View, Text, ScrollView, StyleSheet } from "react-native";

export default function GoldSchemeScreen() {
  const installments = [
    {
      installmentNo: 7,
      receiptNo: "44527",
      rate: "8985.00",
      date: "28-Jun-2025",
      amount: "1500.00",
      weight: "0.278",
      schemeName: "AS JWEllS",
    },
    {
      installmentNo: 6,
      receiptNo: "29836",
      rate: "8935.00",
      date: "28-May-2025",
      amount: "1500.00",
      weight: "0.280",
      schemeName: "AS JWEllS",
    },
    {
      installmentNo: 5,
      receiptNo: "26173",
      rate: "8720.00",
      date: "18-May-2025",
      amount: "1500.00",
      weight: "0.287",
      schemeName: "AS JWEllS",
    },
    {
      installmentNo: 4,
      receiptNo: "6896",
      rate: "8770.00",
      date: "13-Apr-2025",
      amount: "1500.00",
      weight: "0.285",
      schemeName: "AS JWEllS",
    },
    {
      installmentNo: 3,
      receiptNo: "153976",
      rate: "8215.00",
      date: "25-Mar-2025",
      amount: "1500.00",
      weight: "0.304",
      schemeName: "AS JWEllS",
    },
    {
      installmentNo: 2,
      receiptNo: "133603",
      rate: "7940.00",
      date: "13-Feb-2025",
      amount: "1500.00",
      weight: "0.315",
      schemeName: "AS JWEllS",
    },
    {
      installmentNo: 1,
      receiptNo: "23706",
      rate: "7450.00",
      date: "21-Jan-2025",
      amount: "1500.00",
      weight: "0.336",
      schemeName: "AS JWEllS",
    },
  ];

  

  return (
    <ScrollView style={styles.container}>
      
      {installments.map((item, index) => (
        <View key={index} style={styles.card}>
          <Text style={styles.schemeName}>{item.schemeName}</Text>

          <View style={styles.row}>
            <View style={styles.col}>
              <Text style={styles.label}>Installment</Text>
              <Text style={styles.value}>{item.installmentNo}</Text>

              <Text style={styles.label}>Rect No</Text>
              <Text style={styles.value}>{item.receiptNo}</Text>

              <Text style={styles.label}>Rate</Text>
              <Text style={styles.value}>{item.rate}</Text>
            </View>

            <View style={styles.col}>
              <Text style={styles.label}>Date</Text>
              <Text style={styles.value}>{item.date}</Text>

              <Text style={styles.label}>Amount</Text>
              <Text style={styles.value}>{item.amount}</Text>

              <Text style={styles.label}>Weight</Text>
              <Text style={styles.value}>{item.weight}</Text>
            </View>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#f5e8d8",
    padding: 2,
  },
  card: {
    backgroundColor: "#fff8f0",
    borderWidth: 1,
    borderColor: "#d9c7b8",
    borderRadius: 4,
    padding: 13,
    marginBottom: 10,
    elevation: 2,
  },
  schemeName: {
    textAlign: "center",
    fontSize: 16,
    fontWeight: "700",
    marginBottom: 10,
    color: "#7b2c2f",
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  col: {
    width: "40%",
  },
  label: {
    fontSize: 13,
    fontWeight: "600",
    color: "#444",
  },
  value: {
    fontSize: 14,
    marginBottom: 10,
    color: "#000",
  },
});
